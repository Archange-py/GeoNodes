![hexagones](https://raw.githubusercontent.com/Archange-py/GeoNodes/refs/heads/main/Pavage/Examples/hexagones_1_cycles.png)

# GeoNodes

This repository will contain several node/modify add-ons built using Geometry Nodes.  

For now, it includes the Pavage add-on, which can be imported into Blender by simply importing the .zip file. Please note that it is still under construction, so there may be many errors! I will indicate on this repository when it is finished.